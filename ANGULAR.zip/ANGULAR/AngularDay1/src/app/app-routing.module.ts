import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { EmploeelistComponent } from './emploeelist/emploeelist.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { EventComponent } from './event/event.component';
import { TemplateDrivenFormComponent } from './template-driven-form/template-driven-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ProductComponent } from './product/product.component';
import { AuthGuard } from './guards/auth.guard';
import { Assessment1Component } from './lab/assessment1/assessment1.component';
import { ParentComponent } from './parent/parent.component';
import { Assessment2Component } from './lab/assessment2/assessment2.component';

const routes: Routes = [
{path:'',component:HomeComponent},
{path:'about',component:AboutComponent,canActivate:[AuthGuard]},
{path:'contact',component:ContactComponent,canDeactivate:[AuthGuard]},
{path:'emploeelist',component: EmploeelistComponent},
{path:'event',component: EventComponent},
{path:'templatedrivenform',component:TemplateDrivenFormComponent },
{path:'reactiveform',component:ReactiveFormComponent },
{path:'login',component:LoginComponent },
{path:'register',component:RegisterComponent },
{path:'product',component:ProductComponent },
{path:'assessment',component:Assessment1Component  },
{path:'assessment2',component:Assessment2Component  },
{path:'parenttochild',component:ParentComponent  },
{path:'**',component: PageNotFoundComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
