import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'EmployeeDetails';
  firstname: string = "Vijaylaxmi"
  lastname: string = "Mallari";
  Address: string = "Gokak";
  Phonenum: number = 8884624843;


}
