import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmploeelistComponent } from './emploeelist/emploeelist.component';
import { AssignmentComponent } from './assignment/assignment.component';
import { EmpgenderPipe } from './pipe/empgender.pipe';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { EventComponent } from './event/event.component';
import { TemplateDrivenFormComponent } from './template-driven-form/template-driven-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ProductComponent } from './product/product.component';
import { Assessment1Component } from './lab/assessment1/assessment1.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { Assessment2Component } from './lab/assessment2/assessment2.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    EmploeelistComponent,
    AssignmentComponent,
    EmpgenderPipe,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    NavBarComponent,
    PageNotFoundComponent,
    EventComponent,
    TemplateDrivenFormComponent,
    ReactiveFormComponent,
    LoginComponent,
    RegisterComponent,
    ProductComponent,
    Assessment1Component,
    ParentComponent,
    ChildComponent,
    Assessment2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
