import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';

@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.css']
})
export class AssignmentComponent implements OnInit {

  constructor() { }
   Subject:string[] = ["Angular","MongoDB","Express"];

  ShowFaculty:boolean = true;
  Faculty:string = "Vijaylaxmi Hanchate"

  Duration:number = 30;

  isValid:boolean = true;

  //Object
  pro:Product = {
    id:11,
    name:"Note8",
    cost:43434,
    category:"Electronics"

  };

     //Array
     products:Product[]=[
       {id:11,name:"Note8",cost:43434,category:"Electronics"},
       {id:12,name:"Vivo",cost:43434,category:"Electronics"},
       {id:13,name:"Samsung",cost:43434,category:"Electronics"}
     ];
  


  ngOnInit() {
  }

}
