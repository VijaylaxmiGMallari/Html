import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmploeelistComponent } from './emploeelist.component';

describe('EmploeelistComponent', () => {
  let component: EmploeelistComponent;
  let fixture: ComponentFixture<EmploeelistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmploeelistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmploeelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
