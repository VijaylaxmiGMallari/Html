import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emploeelist',
  // template: 'Hello {{name}}',
  templateUrl:`./emploeelist.component.html`,
  styleUrls: ['./emploeelist.component.css']
})
export class EmploeelistComponent implements OnInit {
  //  name:string="Vijaylaxmi";
  constructor() { }
   employee:any[] = [
      {
           code:"emp101",name:"vijaylaxmi",
           gender:"female",annualSalary:20000,dateofBirth:'05/10/1995'
      },
    
     {
       code:"emp102",name:"anusha",
      gender:"male",annualSalary:20000,dateofBirth:'04/11/1995'
      },
    {
      code:"emp101",name:"vijaya",
       gender:"female",annualSalary:20000,dateofBirth:'05/12/1995'
     }


  ];
  ngOnInit() {
  }

}
