import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {

  constructor() { }
  onClick(){
    alert("hello anusha ")
  }

  onDelete(id:number){
    alert(`Product Deleted is :` +id);
  }

  onEdit(id:number,name:string){
    alert(`Product to be Edited is ${id} and ${name}`);
    
  }


  //Name Application
  names:any[]= ["Vijaylaxmi","Anusha"];



  addNames(name:string){
    alert(name);
    this.names.push(name);
  }

  deleteName(name:string){
    alert('name to be deleted'+name);
    let indexpotition=this.names.indexOf(name);
    this.names.splice(indexpotition,1);
  }
  ngOnInit() {
  }

}
