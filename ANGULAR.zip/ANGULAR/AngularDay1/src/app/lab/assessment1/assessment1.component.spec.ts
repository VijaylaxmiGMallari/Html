import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Assessment1Component } from './assessment1.component';

describe('Assessment1Component', () => {
  let component: Assessment1Component;
  let fixture: ComponentFixture<Assessment1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Assessment1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Assessment1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
