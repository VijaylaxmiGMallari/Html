import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assessment1',
  templateUrl: './assessment1.component.html',
  styleUrls: ['./assessment1.component.css']
})
export class Assessment1Component implements OnInit {
  //custom two way binding
// value:string="";
  constructor() { }
  //two way binding
   id:number;
    name:string;
    salary:number;
   department:string;
   addEmployee(){
     alert(this.id+this.name+this.salary+this.department)
   }

  ngOnInit() {
  }

}
