import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assessment2',
  templateUrl: './assessment2.component.html',
  styleUrls: ['./assessment2.component.css']
})
export class Assessment2Component implements OnInit {

  constructor() { }








  
  ngOnInit() {
  }

}
