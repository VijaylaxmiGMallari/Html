import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import{Product} from '../model/product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
   products:Product[]=[];
  productToService: any;
  proService: any;
  constructor(private proservice:ProductService  ) { }

  ngOnInit() {
    this.products=this.proservice.getProducts();
  }
  
  deleteproductFromService(product:Product){
    this.proservice.deleteproduct(product);
  }


  addproductsToService(id,productname,cost,category){
    this.proservice.addproduct(id,productname,cost,category);
  }

  deletefromservice1(proid)



{



let index =0;



for(let
pro of 
this.products)



{



if(pro.id==proid)



{



this.products.splice(index,1);



}



index++;



}



}



  @ViewChild('refproductid')prodtidInput:ElementRef;
  @ViewChild('refproductname')prodtnameInput:ElementRef;
  @ViewChild('refproductcost')prodtcostInput:ElementRef;
  @ViewChild('refproductcategory')prodtcategoryInput:ElementRef;

  clearTextboxes(){
    this.prodtidInput.nativeElement.value = '';
    this.prodtnameInput.nativeElement.value = '';
    this.prodtcostInput.nativeElement.value = '';
    this.prodtcategoryInput.nativeElement.value = '';
  }

  update(id,name,cost,category){
    this.proservice.updateproduct(id,name,cost,category);
  }
}
