import { Component, OnInit } from '@angular/core';
import{FormGroup,FormControl,Validators}  from '@angular/forms';
import { User } from '../model/User';
@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
form:FormGroup;
userlist:User[]=[]
  constructor() { }

  ngOnInit() {
    this.form= new FormGroup(
      {
        name:new FormControl(' ',[Validators.required,Validators.pattern('[a-zA-Z][a-zA-Z]+')]),
        contact:new FormControl(' ',[Validators.required,Validators.pattern('[6-9][0-9]*')]),
        email:new FormControl(' ',[Validators.required,Validators.pattern('[a-zA-Z][a-zA-Z]+')])
      }
    )
  }

  AddUser(form){
    this.userlist.push(form.value);
    console.log(form.value);
  }

}
