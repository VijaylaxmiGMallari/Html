import { Injectable } from '@angular/core';
import{Product} from '../model/product';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  products:Product[]=[
    {id:1, name:'laptop',cost:1000,category:'Electronics'},
    {id:2, name:'Mobile',cost:2000,category:'Electronics'},
    {id:3, name:'fan',cost:3000,category:'Electronics'}
  ];
  
  

  //crating a method (get)
  //to call a product
  getProducts(){
    return this.products;
  }

  addproduct(id:number,productname:string,cost:number,category:string){
    let newproduct={
      // id:this.products.length+1, //index will be added like sr.no
      id:id,
      name:productname,cost:cost,
      category:category
    };
    return this.products.push(newproduct);
  }

  deleteproduct(product:Product){
    let indexPosition = this.products.indexOf(product);
    return this.products.splice(indexPosition,1);
  }

  updateproduct(id,name,cost,category){
    let updateid=id;
    for(let pro of this.products){
      if(pro.id == updateid){
        pro.id = id;
        pro.name = name;
        pro.cost = cost;
        pro.category = category;
      }
    }
    return this.products;
  }

  constructor() { }
}
