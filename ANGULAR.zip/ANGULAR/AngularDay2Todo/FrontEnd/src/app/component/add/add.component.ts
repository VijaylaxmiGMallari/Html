import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DoingService } from 'src/app/service/doing.service';




@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  addForm:FormGroup;
  submitted:boolean=false;

  constructor(private formbuilder:FormBuilder,private router:Router,
    private userservice:DoingService) { }

  ngOnInit() {
    this.addForm=this.formbuilder.group({
      
      firstname:['',Validators.required],
      task:['',Validators.required]
     
  });
  }
  onSubmit(){
    //write a data to fetch the data from service
    this.submitted=true;
    if(this.addForm.invalid){
      return;
    }
    this.userservice.createuser(this.addForm.value)
    .subscribe(data=>{alert(this.addForm.value.id+'record addedd')
    });
  
    this.router.navigate(['todo']);
  }


}
