import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DoingService } from 'src/app/service/doing.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  editForm:FormGroup;
  submitted:boolean=false;

  constructor(private formbuilder:FormBuilder,private router:Router,
    private userservice:DoingService) { }

  ngOnInit() {
    if(localStorage.getItem("username")!=null)
    {
      let userId = localStorage.getItem("editId");
      if(!userId){
        alert('Invalid Action');
        this.router.navigate(['todo']);
        return;
      }
    
    this.editForm=this.formbuilder.group({
      id:[],
      firstname:['',Validators.required],
      task:['',Validators.required]
      
  });
  this.userservice.getUserById(+userId).subscribe(data=>{
    this.editForm.setValue(data)
  });

}
else{
  this.router.navigate(['/login']);
}
  }
onSubmit(){
  //write a data to fetch the data from service
  this.submitted=true;
  if(this.editForm.invalid){
    return;
  }
  this.userservice.onEdit(this.editForm.value).
     subscribe(data=>{
       this.router.navigate(['todo']);
     },error=>{
       alert(error);
     });
 
}
  }

