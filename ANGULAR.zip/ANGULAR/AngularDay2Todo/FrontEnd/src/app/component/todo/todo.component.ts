import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DoingService } from 'src/app/service/doing.service';
import { User } from 'src/app/model/toDo';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  users:User[];
  constructor(private userservice:DoingService,private router:Router) { }

  ngOnInit() {
    if(localStorage.getItem("username")!=null){
      this.userservice.getusers()
      .subscribe(data=>{
        this.users = data;
      });
    }
    else{
      this.router.navigate(['login']);
    }
  }
  adduser():void{
    this.router.navigate(['add'])
  }

 
  //logoff
  //logoff User
 logOutUser():void{
  if(localStorage.getItem("username")!=null){
    localStorage.removeItem("username");
    this.router.navigate(['/login']);
  }
}

//delete
onDelete(emp:User):void{
  let result = confirm("Do you want to delete")
  if(result){
    this.userservice.onDelete(emp.id).subscribe(data=>{
      this.users = this.users.filter(u=>u!==emp);
    })
    
  }
}

//edit
onEdit(emp:User):void{
  localStorage.removeItem("editId")
  localStorage.setItem("editId",emp.id.toString());
this.router.navigate(['edit']);
}




}
