export class User{
    id:number;
    firstname:string;
    task:string;
   
}