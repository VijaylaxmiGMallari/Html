import { TestBed } from '@angular/core/testing';

import { DoingService } from './doing.service';

describe('DoingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DoingService = TestBed.get(DoingService);
    expect(service).toBeTruthy();
  });
});
