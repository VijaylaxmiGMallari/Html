import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/toDo';

@Injectable({
  providedIn: 'root'
})
export class DoingService {

  baseurl:string="http://localhost:3000/users";

  constructor(private http:HttpClient) { }

  getusers(){
    return this.http.get<User[]>(this.baseurl);
  }

  createuser(emp:User){
    return this.http.post(this.baseurl,emp);
  }

  onDelete(id:number){
    return this.http.delete(this.baseurl+"/"+id)
  }

  getUserById(id:number){
    return this.http.get<User[]>(this.baseurl+"/"+id)
  }

   //Modify user
   onEdit(user:User){
    return this.http.put(this.baseurl+"/" +user.id, user);
  }
 




 


}
