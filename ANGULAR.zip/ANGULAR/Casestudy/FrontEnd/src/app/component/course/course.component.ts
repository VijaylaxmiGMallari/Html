import { Component, OnInit } from '@angular/core';
import { Courses } from 'src/app/model/courses';
import { Router } from '@angular/router';
import { CoursesService } from 'src/app/service/courses.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  course:Courses[]=[];
  courseduration:string;
  addForm:FormGroup;
  submitted:boolean=false;
  flag:boolean=false;

  constructor(private courseservice:CoursesService,
    private router:Router,private formbuilder:FormBuilder) { }

  ngOnInit() {
    this.addForm=this.formbuilder.group({
      
      coursename:['',Validators.required],
      courseduration:['',Validators.required]
     
  });
      this.courseservice.getcourses()
      .subscribe(data=>{
        this.course = data;
      });
      
     }


  

  onSubmit(){
    this.submitted=true;
    if(this.addForm.invalid){
      return;
    }
    this.courseservice.createuser(this.addForm.value)
    .subscribe(data=>{
    });
  
    this.router.navigate(['course']);
  }
  
  getDuration(cors) {
    this.flag=false

    for(let i of this.course){
    
    if(cors==i.coursename){
    this.flag=true
    this.courseduration=i.courseduration;
    
    }
    

    
    }
    if(this.flag==false) {
      
         alert('Enter Valid CourseName')
         this.courseduration=null;
        

       
    }
  
    
    }
  

  
  }


