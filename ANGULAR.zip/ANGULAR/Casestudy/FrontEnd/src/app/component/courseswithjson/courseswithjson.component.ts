import { Component, OnInit } from '@angular/core';
import { Coursewithjson } from 'src/app/model/course';
import { CoursesService } from 'src/app/service/courses.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-courseswithjson',
  templateUrl: './courseswithjson.component.html',
  styleUrls: ['./courseswithjson.component.css']
})
export class CourseswithjsonComponent implements OnInit {
courses:Coursewithjson[]
  constructor(private courseservice:CoursesService,private router:Router) { }

  ngOnInit() {
    
    
      this.courseservice.getjsoncourses()
      .subscribe(data=>{
        this.courses = data;
      });
    

  }

  

}
