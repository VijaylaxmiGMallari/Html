export class Coursewithjson{
    id:number;
    jsoncoursename:string;
    jsoncourseprice:number;
   
}