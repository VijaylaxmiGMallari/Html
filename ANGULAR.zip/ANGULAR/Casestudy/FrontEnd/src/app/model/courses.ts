export class Courses{
    id:number;
    coursename:string;
    courseduration:string;
}