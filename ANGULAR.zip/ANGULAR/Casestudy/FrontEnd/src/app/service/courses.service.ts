import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Coursewithjson } from '../model/course';
import { Courses } from '../model/courses';
import { DataexcessService } from './dataexcess.service';


@Injectable({
  providedIn: 'root'
})
export class CoursesService {
  


  constructor(private dataexcess:DataexcessService) { }

  getjsoncourses(){
    return this.dataexcess.getjsoncourse();
  }

  getcourses(){
    return this.dataexcess.getcourse();
  }

  createuser(emp:Courses){
    return this.dataexcess.createusers(emp);
  }

  getUserById(id:number){
    return this.dataexcess.getUsersById(id)
  }
}
