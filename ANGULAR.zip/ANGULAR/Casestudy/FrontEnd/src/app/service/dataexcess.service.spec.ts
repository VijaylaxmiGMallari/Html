import { TestBed } from '@angular/core/testing';

import { DataexcessService } from './dataexcess.service';

describe('DataexcessService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DataexcessService = TestBed.get(DataexcessService);
    expect(service).toBeTruthy();
  });
});
