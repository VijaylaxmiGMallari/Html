import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Coursewithjson } from '../model/course';
import { Courses } from '../model/courses';

@Injectable({
  providedIn: 'root'
})
export class DataexcessService {
  coursesurl:string=" http://localhost:3000/course";
  coursewithjsonurl:string="http://localhost:3000/courseswithjson";


  constructor(private http:HttpClient) { }

  getjsoncourse(){
    return this.http.get<Coursewithjson[]>(this.coursewithjsonurl);
  }

  getcourse(){
    return this.http.get<Courses[]>(this.coursesurl);
  }

  createusers(emp:Courses){
    return this.http.post(this.coursesurl,emp);
  }

  getUsersById(id:number){
    return this.http.get<Courses[]>(this.coursesurl+"/"+id)
  }
}
