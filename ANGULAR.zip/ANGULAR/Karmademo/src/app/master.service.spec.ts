// import { TestBed } from '@angular/core/testing';

// import { MasterService } from './master.service';

// describe('MasterService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: MasterService = TestBed.get(MasterService);
//     expect(service).toBeTruthy();
//   });
// }

import { MasterService } from './master.service';
import{ValueService} from "./value.service"
describe('MasterService Testing',() =>{
let masterservice:MasterService;
//testing of real service
it('should return Hello World from another service',() =>{
  masterservice= new MasterService(new ValueService);
  expect(masterservice.getValue()).toBe("Hello World")
})
})
