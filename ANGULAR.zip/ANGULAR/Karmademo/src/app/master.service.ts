import { Injectable } from '@angular/core';
import { ValueService } from './value.service';
import { getQueryValue } from '@angular/core/src/view/query';

@Injectable({
  providedIn: 'root'
})
export class MasterService {

  constructor(private valueservice:ValueService) {

   }
   getValue(){
     return this.valueservice.getData();
  }


}
