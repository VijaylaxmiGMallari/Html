import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
 addForm:FormGroup;
 submitted:boolean=false;
  constructor(private formbuilder:FormBuilder,private router:Router,
         private userservice:UserService) { }

  ngOnInit() {
    this.addForm=this.formbuilder.group({
      id:[],
      firstname:['',Validators.required],
      lastname:['',Validators.required],
      email:['',Validators.required]
  });

}

onSubmit(){
  //write a data to fetch the data from service
  this.submitted=true;
  if(this.addForm.invalid){
    return;
  }
  this.userservice.createuser(this.addForm.value)
  .subscribe(data=>{alert(this.addForm.value.firstname+'record addedd')
  });

  this.router.navigate(['listuser']);
}
}