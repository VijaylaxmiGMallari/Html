import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/model/user';

@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent implements OnInit {
  users:User[];
  constructor(private userservice:UserService,private router:Router) { }

  ngOnInit() {
    if(localStorage.getItem("username")!=null){
      this.userservice.getusers()
      .subscribe(data=>{
        this.users = data;
      });
    }
    else{``
      this.router.navigate(['login']);
    }
  }
  onDelete(emp:User):void{
    let result = confirm("Do you want to delete")
    if(result){
      this.userservice.onDelete(emp.id).subscribe(data=>{
        this.users = this.users.filter(u=>u!==emp);
      })
      
    }
 }


 adduser():void{
   this.router.navigate(['adduser'])
 }


 //logoff User
 logOutUser():void{
   if(localStorage.getItem("username")!=null){
     localStorage.removeItem("username");
     this.router.navigate(['/login']);
   }
 }
 onEdit(emp:User):void{
   localStorage.removeItem("editId")
   localStorage.setItem("editId",emp.id.toString());
 this.router.navigate(['edit']);
}



}
