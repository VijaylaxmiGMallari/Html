import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseurl:string="http://localhost:3000/users";

  constructor(private http:HttpClient) { }

  //Modify user
  onEdit(user:User){
    return this.http.put(this.baseurl+"/" +user.id, user);
  }

  getusers(){
    return this.http.get<User[]>(this.baseurl);
  }

  onDelete(id:number){
    return this.http.delete(this.baseurl+"/"+id)
  }

  createuser(emp:User){
    return this.http.post(this.baseurl,emp);
  }

 getUserById(id:number){
   return this.http.get<User[]>(this.baseurl+"/"+id)
 }

}
