import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Item } from 'src/app/model/product';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  editForm:FormGroup
isedit:boolean=false;
  item:Item[]=[];
  router: any;
  submitted:boolean=false;
  constructor( private productservice:ProductService,private formbuilder:FormBuilder) { }

  ngOnInit() {
    this.isedit=true;
    if(localStorage.getItem("username")!=null)
    {
      let itemId = localStorage.getItem("editId");
      if(!itemId){
        alert('Invalid Action');
        this.router.navigate(['item']);
        return;
      }
    
    this.editForm=this.formbuilder.group({
     
      itemname:['',Validators.required],
      itemquantity:['',Validators.required],
      itembought:['',Validators.required]
      
  });
  this.productservice.getUserById(+itemId).subscribe(data=>{
    this.editForm.setValue(data)
  });

}

    
  }

  update(){

    this.submitted=true;
    if(this.editForm.invalid){
      return;
    }
    this.productservice.updateshoppingitem(this.editForm.value).
       subscribe(data=>{
         this.router.navigate(['']);
       },error=>{
         alert(error);
       });
  }

  




}

 
   

