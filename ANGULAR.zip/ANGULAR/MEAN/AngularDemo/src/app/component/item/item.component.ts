import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from 'src/app/service/product.service';
import { Item } from 'src/app/model/product';


@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {
  shoppingitemlist:Item[]=[];

adForm:FormGroup


  constructor(private formbuilder:FormBuilder,private router:Router,
    private productservice:ProductService) { }

  ngOnInit() {
    this.getitems();

    this.adForm=this.formbuilder.group({
      itemname:[''],
      itemquantity:[''],
      itembought:['']
 
    })
     
  }
  getitems(){
    this.productservice.getshopingitems().subscribe(items=>{
      this.shoppingitemlist=<Item[]>items
    })
  }
  add(){
    this.productservice.addshopingitem(this.adForm.value).subscribe(data=>{})
    console.log(this.adForm.value)
  }

  delete(it:Item){
    let result = confirm("Do you want to delete")
  
    if(result){
      this.productservice.deleteshoppingItem(it._id).subscribe(result=>{
        this.shoppingitemlist = this.shoppingitemlist.filter(u=>u!==it);
      })
      
    }

  }

  edit(it:Item){
    this.router.navigate(['edit']);
  }

 

  // delete(_id) {
  //   alert('hi')
  //   this.productservice.delete(_id)
  //     .subscribe(result=> {
  //       console.log(result);
  //   for (var
  //   i = 0;
  //   i < this.shoppingitemlist.length;
  //   i++) {
    
  //   if (_id ==
  //   this.shoppingitemlist[i]._id) {
    
  //   this.shoppingitemlist.splice(i,
  //   1);
    
  //   }
    
  //   }
    
  //   })
  // }

}
  


  
  

    
  

  



