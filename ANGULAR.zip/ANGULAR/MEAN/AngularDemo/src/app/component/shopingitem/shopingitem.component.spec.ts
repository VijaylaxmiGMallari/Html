import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShopingitemComponent } from './shopingitem.component';

describe('ShopingitemComponent', () => {
  let component: ShopingitemComponent;
  let fixture: ComponentFixture<ShopingitemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShopingitemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShopingitemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
