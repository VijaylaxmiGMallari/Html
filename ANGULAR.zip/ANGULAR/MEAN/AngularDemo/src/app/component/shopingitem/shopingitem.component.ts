import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/service/product.service';
import { Item } from 'src/app/model/product';

@Component({
  selector: 'app-shopingitem',
  templateUrl: './shopingitem.component.html',
  styleUrls: ['./shopingitem.component.css']
})
export class ShopingitemComponent implements OnInit {
  shoppingitemlist:Item[]=[];
  selectedItem: Item;
  toggleForm: Boolean = false;
  constructor(  private productservice:ProductService) { }

  ngOnInit() {
    this.getitems();
  }

  getitems(){
    this.productservice.getshopingitems().subscribe(items=>{
      this.shoppingitemlist=<Item[]>items
    })
  }

  addItem(frm){
    console.log(frm.value);
    let newitem:Item={
      itemname:frm.value.itemname,
      itemquantity:frm.value.itemquantity,
      itembought:false
    }
    this.productservice.addshopingitem(newitem).subscribe(item=>{
      console.log(item);
      this.getitems();
    })
  }

  editForm(editfrm) {

    let 
    newItem: Item = {
    
    _id: 
    this.selectedItem._id,
    
    itemname: editfrm.value.itemname,
    
    itemquantity: 
    editfrm.value.itemquantity,
    
    itembought: 
    this.selectedItem.itembought
    
    }
    
    this.productservice.updateshoppingitem(newItem)
    
    
    
    .subscribe(result => {
    
    console.log('original item to be updated with old values' +
    result);
    
    this.getitems();
    
    this.toggleForm = !this.toggleForm;
    
    })
    
    
    
    }
    
    showEditform(Item) {
    
    this.selectedItem =
    Item;
    
    this.toggleForm = !this.toggleForm;
    
    }
    
    
    
    
    
    updateItemcheckbox(item) {
    
    item.itemboughts = !item.itemboughts;
    
    this.productservice.updateshoppingitem(item)
    
    .subscribe(result=> {
    
    // console.log('Original CheckBox values' + result.itemboughts);
    
    // item.getItems();
    
    })
    
    }
    
    
    
    deleteItem(id) {
    
    this.productservice.deleteshoppingItem(id)
    
    .subscribe(result => {
    
    console.log(result);
    
    
    
    for (var
    i = 0;
    i < this.shoppingitemlist.length;
    i++) {
    
    if (id ==
    this.shoppingitemlist[i]._id) {
    
    this.shoppingitemlist.splice(i,
    1);
    
    }
    
    }
    
    })
    
    }
    
}

