export class Item{
    itemname:string;
    itemquantity:number;
    itembought:boolean;
    _id?:number;

}