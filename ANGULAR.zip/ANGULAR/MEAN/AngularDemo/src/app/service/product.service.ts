import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Item } from '../model/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

baseurl:string="http://localhost:500/api/item";

  constructor(private http:HttpClient) { }
  getshopingitems(){
    return this.http.get<Item[]>('http://localhost:500/api/items');
    
    }
    addshopingitem(item:Item){
      return this.http.post('http://localhost:500/api/item',item)
    }

    deleteshoppingItem(_id:number){
      return this.http.delete(this.baseurl+"/"+_id)
    }

    updateshoppingitem(Item:Item){
      
      return this.http.put('http://localhost:500/item',
      Item);
      
      }

      
      getUserById(id:number){
        return this.http.get<Item[]>(this.baseurl+"/"+id)
      }

      onEdit(item:Item){
        return this.http.put(this.baseurl+"/" +item._id, item);
      }


    
}

