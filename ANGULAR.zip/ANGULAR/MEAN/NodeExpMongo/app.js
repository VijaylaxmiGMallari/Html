var express=require('express');
var mongoose= require('mongoose');
var cors=require('cors');
//import the router file
const route=require('./router/router');


mongoose.connect('mongodb://localhost:27017/mydb')
mongoose.connection.on('connected',()=>{
    console.log('Mongoose connected to 27017')
})

var app=new express();

app.get('/',(req,res)=>{
    res.send('Hello from Root Path');
});

//add a middleware to parse the data
app.use(express.json());
app.use(cors());
//add an middleware to use routes
app.use('/api',route);

const port=5000;
app.listen(port,function(){
    console.log('Server started on port number',port)
})