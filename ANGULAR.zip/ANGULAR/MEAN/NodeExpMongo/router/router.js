var express=require('express');
var router = express.Router();
const item=require('../model/items');

router.get('/',(req,res)=>{
    console.log('I am from different router module');
})


router.post('/item',(req,res,next)=>{
    const newitem=new item({
        itemname:req.body.itemname,
        itemquantity:req.body.itemquantity,
        itembought:req.body.itembought,
    });

newitem.save((err,item)=>{
    if(err){
        res.json(err);
    }
    else{
        res.json({msg:'inserted'});
    }
});
});//post close

router.get('/items',(req,res,next)=>{
    item.find(function (err, items){
    if(err){
        res.json(err);
    }
    else{
   res.json(items)
    }

 
});
});//get close

router.delete('/item/:id',(req,res,next)=>{
    item.remove({_id:req.params.id},function (err, result){
    if(err){
        res.json(err);
    }
    else{
   res.json(result);
    }

 
});
});//get delete

//update

router.put('/item/:id',(req,res,next)=>
{
   item.findByIdAndUpdate(req.params.id,req.body,(err,items)=>
{  if(err) {
           res.json(err);
        }
   else { 
       res.json(items);
       } 
    })


})//end of update



router.put('/item')

module.exports=router;