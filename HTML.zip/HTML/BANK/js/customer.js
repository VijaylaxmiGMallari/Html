 function calculateLogin(fromloginObj)
 {
     if(fromloginObj.checkValidity())
     {
         var username=fromloginObj.txtUn.value;

         var password =fromloginObj.txtPd.value;
         alert(username)
         alert(password)
         if(username=="vijaylaxmi" && password=="123456")
         {
             alert('Login successful')
         }
     }
 }
 
 
 
 
 
 function  myRegister(idnum,firstname,lastname,
    age,accountnum,balance){
        this.idnum = idnum;
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
        this.accountnum = accountnum;
        this.balance = balance;

   var details = `Customer Id:${this.idum}\n
                  Customer firstname:${this.firstname}\n
                  Customer lastname:${this.lastname}\n
                  Customer age:${this.age}\n
                  Customer accountnum:${this.accountnum}\n
                  Customer balance:${this.balance}`;
                   
        alert(details)
    }