function findstate(frm){
    if(frm.checkValidity())
    {
        var win = window.open("","preview", width="100px",
        height="100px");

        // win.document.write("<html><head> <title> Employee details 
        // </title></head> </body>");
        win.document.write("<h1> Employee details </h1>");
        win.document.write("<p> First Name is " + 
        frm[0].value+ "</p>");
        win.document.write("<p> Last Name is " + 
        frm[1].value+ "</p>");
        win.document.write("<p> Contact Number is " + 
        frm[2].value+ "</p>");
        win.document.write("<p> Email address is " + 
        frm[3].value+ "</p>");
        win.document.write("<p> date of birth is " + 
        frm[4].value+ "</p>");
        win.document.write("<p>state is " + 
        frm[5].value+ "</p>");
        win.document.write("<p> city is is " + 
        frm[5].options[frm[5].selectedIndex].text+ "</p>");
    }
}
