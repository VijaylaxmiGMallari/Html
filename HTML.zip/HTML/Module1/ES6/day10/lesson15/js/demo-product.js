class product {
    constructor(productId,productName,productPrice,productDescription){
               this._productId_=productId;
               this._productName_=productName;
               this._productPrice_=productPrice;
               this._productDescription_=productDescription;

    }
    // function
    printAllProduct() {
        var productDetails=
        `product Id: ${this._productId_}
        product Name: ${this._productName_}
        product Price: ${this._productPrice_}
        product Description: ${this._productDescription_}
        `;
return productDetails;
    }
}// end of product class

class product1 extends product{
    constructor(productId,productName,
        productPrice,productDescription,productType){
            super(productId,productName,
                productPrice,productDescription);
                this._productType_=productType;
        }
        //function
        printAllProduct() {
            let allDetails=super.printAllProduct()+
            "product type :" +this._productType_;
            return allDetails;
        }
}// end of product1 class


class product2 extends product{
    constructor(productId,productName,
        productPrice,productDescription,productCategory){
            super(productId,productName,
                productPrice,productDescription);
                this._productCategory_=productCategory;
        }
        //function
        printAllProduct() {
            let allDetails=super.printAllProduct()+
            "product category :" +  this._productCategory_;
            return allDetails;
        }
}// end of product 2
var product1Obj=new product1("p1","Laptop",25000,
"personal","education");
// console.log(product1Obj.printAllProduct());

var product2Obj=new product2("p2","AC",5000,
"personal","home appliance");
// console.log(product2Obj.printAllProduct());

var product3Obj=new product2("p3","Fan",15000,
"personal","home appliance");

var product4Obj=new product1("p4","AC",85000,
"personal","home appliance");

let allProducts=[];
//crud operation
//add array
allProducts.push(product1Obj);
allProducts.push(product2Obj);
allProducts.push(product3Obj);
allProducts.push(product4Obj);


//reading array
for( let productt in allProducts){
    console.log(allProducts[productt].printAllProduct());
}
//sort

console.log("after sorting in ascending order");
allProducts.sort((a,b) => a._productPrice_ -b._productPrice_);

for(var productt in allProducts) {
    console.log(allProducts[productt].printAllProduct());
}


//updating  from an array
// let productId=prompt("enter product id");
// for(var productt in allProducts){
//      if(allProducts[productt]._productId_===productId) {
//           allProducts[productt]._productName_ = "HP Laptop";


//      }
// else {
//     console.log("product ID doesnot exist");
// }
// }
// console.log("after changing product name");
// //reading from array
// for( var productt in allProducts){
//     console.log(allProducts[productt].printAllProduct());
// }


// // deleting an array
// let productId=prompt("enter product id");
// for(let product in allProducts){
//      if(allProducts[productt]._productId_===productId) {
//         allProducts.splice(product,1);
//      }
//     }
//     console.log("after removing product name");
// //reading from array
// for( var productt in allProducts){
//     console.log(allProducts[productt].printAllProduct());
// }
