//Create class rectangle
class rectangle{
      constructor(){
          console.log("Constructor of Rectangle class is called..!");
      }

      calculateArea(l,b){
          let area = l*b;
          return area;
      }
}
 let recObj = new rectangle();
 let length = parseFloat(prompt("Enter the length: "));
 let breadth = parseFloat(prompt("Enter the breadth: "));

 let area = recObj.calculateArea(length,breadth);
 console.log(area);


//  class square{
//      constructor(){
//          console.log("Constructor of square class is called..!");
//      }

//      calculateArea2(s){
//          let area2 = s*s;
//          return area2;
//      }
//  }
//  let squObj = new square();
//  let side = parseFloat(prompt("Enter the side: "));
 

//  let area2 = squObj.calculateArea(side);
//  console.log(area2);