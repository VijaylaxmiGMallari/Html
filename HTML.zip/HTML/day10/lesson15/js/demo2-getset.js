//Create class rectangle
class rectangle{
    constructor(length,breadth){
       this._length_ = length;
       this._breadth_ = breadth;
    }

    //setting length
    set length(length){
        this._length_ = length; 
    }

    //getting breadth
    get length(){
        return this._length_;
    }

    //setting breadth
    set breadth(breadth){
        this._breadth_ = breadth; 
    }
  
    get breadth(){
        return this._breadth_;
    }

//non static function we require object to invoke
    // calculateArea(){
    //     let area = this._length_*this._breadth_;
    //     return area;
    // }

    //static function- We require class name to invoke it
    static display(){
        return "Area of Rectangle is";
    }
    //non-static function-We require object to invoke it
         calculateArea(){
        let area = this._length_*this._breadth_;
        return area;
    }
}

let length = parseFloat(prompt("Enter the length: "));
let breadth = parseFloat(prompt("Enter the breadth: "));

//creating the Rectangle class object
let rectObj1 = new rectangle();
//initializing with Properties i.e get and set methods
rectObj1.length=length;
rectObj1.breadth=breadth;

//Invoking non static function using Object
   let area1 = rectObj1.calculateArea();
console.log("Using Properties-Area of rectangle is:" 
   +rectangle.display()+" "+area1);

//2nd way using constructor for initialization
//creating the class object
let rectObj2 = new rectangle(length,breadth);

 let area2 = rectObj2.calculateArea();
console.log("Using Properties-Area of rectangle is:"  +area2);