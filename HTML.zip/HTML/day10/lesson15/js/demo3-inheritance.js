//constructors in order of base to derived
class BaseClass{
    constructor(){
        console.log("Base class is called..!");
    }
}

//Inheriting from Base class
class DerivedClass extends BaseClass{
    constructor(){
        //This is mandatory in derived class
        super();
        console.log("Derived class is called..!");
    }
}
let DerivedObj = new DerivedClass();
//O/P: Base class is called..!
//  Derived class is called..!

//Parent class or super class
 class Employee{
       constructor(id,name,salary){
         this._id_ = id;
         this._name_ = name;
         this._salary_ = salary;
       }
       showDetails(){
           let details = `Emp Id:${this._id_}
                          Name:${this._name_}
                          Salary:${this._salary_}
                          `;
         return details;
       }
     }

// //Child class or sub class
     class Manager extends Employee{
     constructor(id,name,salary,deptName){
         //super keyword is used to call
         //base class constructor to initialize
         //derived class members
         super(id, name, salary);
         this._deptName_ = deptName;
    }

    //Overriding base class function inside derived class
    //is called as function overriding
    showDetails(){
        return "Department Name: "+this._deptName_+" "+super.showDetails();
    }
 }

 var mgrObj = new Manager(101,"Anusha",25000,"IT");
 console.log(mgrObj.showDetails());

 //super keyword points to immediate base class
 //super keyword in derived class,it is used to invoke base class
 //constructor
 //super keyword is also used to invoke base class members and function
 //it avoids ambguity between base class members and derived class members

 class superClass{
     constructor(id){
         this._cid_ = 20;
     }
     display(){
         return this._cid_;
     }
 }

 class subClass extends superClass{
    constructor(){
        super();
        this._id_ = 10;
    }
    display(){
        console.log("Instance variable: "+this._id_);
        console.log("Instance variable: "+super.display());
    }
}

let subObj = new subClass();
subObj.display();

class shape{
    constructor(radius)
}