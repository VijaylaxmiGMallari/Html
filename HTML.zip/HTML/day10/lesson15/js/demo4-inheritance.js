class superClassshape{
    constructor(radius,length,breadth){
        this._radius_ = 10;
        this._length_ = 20;
        this._breadth_ = 30;

    }
       display(){
         return this._cid_;
       }
}

class subClasscircle extends superClassshape{
   constructor(){
       super();
       this._radius_ = 10;
       this._area_ = 3.142*this._radius_;
   }
   display(){
       console.log("Instance variable: "+this._area_);
       console.log("Instance variable: "+this._radius_);
   }
}

let subObj = new subClasscircle();
subObj.display();

class subreactangleClass extends superClassshape{
    constructor(){
        super();
        this._length_ = 20;
        this._breadth_ = 30;
        this._area1_ = this._length_*this._breadth_;
    }
    display(){
        console.log("Instance variable: "+this._area1_);
        console.log("Instance variable: "+this._breadth_);
        console.log("Instance variable: "+this._length_);
    }
 }
let subbObj = new subreactangleClass();
subbObj.display();
