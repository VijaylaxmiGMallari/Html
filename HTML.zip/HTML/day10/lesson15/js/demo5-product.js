class product{
    constructor(productId,productName,
           productPrice,productDescription){
             this._productId_ = productId;
             this._productName_ = productName;
             this._productPrice_ = productPrice;
             this._productDescription_ = productDescription;
           }
           printAllProduct(){
               var productDetails =
                           `Product Id: ${this._productId_}
                           Product Name: ${this._productName_}
                           Product Price: ${this._productPrice_}
                           Product Description: ${this._productDescription_}`;
                          
                      return productDetails;     
           }
}

class Product1 extends product{
    constructor(productId,productName,
        productPrice,productDescription,productType){
            super(productId,productName,
                productPrice,productDescription);
                this._productType_ = productType;
        }
    printAllProduct(){
        let allDetails = super.printAllProduct() + 
        "Product Type: "+ this._productType_;
        return allDetails;
    }

}//End of product1 class

class Product2 extends product{
    constructor(productId,productName,
        productPrice,productDescription,productCategory){
            super(productId,productName,
                productPrice,productDescription);
                this._productType_ = productCategory;
        }
    printAllProduct(){
        let allDetails = super.printAllProduct() + 
        "Product Category: "+ this._productCategory_;
        return allDetails;
    }

}//End of product2 class

var product1Obj = new Product1("P1","Laptop",5000,
                                "My personalLaptop","Education");
   console.log(product1Obj.printAllProduct());

   var product2Obj = new Product2("P2","Refrigerator",25000,
                                "Refrigerator for making things cool",
                                "Home Applisnce");
//    console.log(product2Obj.printAllProduct());

var product3Obj = new Product2("P3","Laptop",5000,
                                "My personalLaptop","Education");
   console.log(product1Obj.printAllProduct());

   var product4Obj = new Product1("P4","Refrigerator",25000,
                                "Refrigerator for making things cool",
                                "Home Applisnce");

   let allProducts = [];
   //CRUD Operation
   //Adding to Array-> CREATE
   allProducts.push(product1Obj);
   allProducts.push(product2Obj);
   allProducts.push(product3Obj);
   allProducts.push(product4Obj);



   //Reading From an array -> READ
   for (var prroduct in allProducts){
       console.log(allProducts[prroduct].printAllProduct());
   }

   console.log("After sorting in ascending order");
   allProducts.sort((a,b) => a._productPrice_ -b._productPrice_);

//    //updating From an Array ->UPDATE
//    let productId = prompt("Enter Product Id ");
//    for(var prroduct in allProducts){
//        if(allProducts[prroduct]._productId_=== productId){
//         allProducts[prroduct]._productName_ = "HP Laptop" ;
//        }
//        else{
//            console.log("Product Id does not Exist ");
//        }
//       }
   

   //Removing From an Array ->DELETE
//    let productId = prompt("Enter Product Id");
//    for (var productt in allProducts){
//        if (allProducts[productt]._producttId_ === productId){
//            allProducts.splice(productt,1);
//        }
//    }
//    console.log("After Removing Product: ");
//    //Reading from an array ->Read
//     console.log(allProducts[productt].printAllProduct());
