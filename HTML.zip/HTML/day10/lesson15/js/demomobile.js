class mobile{
    constructor(mobileId,mobileName,mobileDescription){
        this._mobileId_ = mobileId;
        this._mobileName_ = mobileName;
        this._mobileDescription_ = mobileDescription;
    }
    printMobiledetails(){
        var mobDetails=
                           `Mobile Id=${this._mobileId_}
                            Mobile Name= ${this._mobileName_}
                            Mobile Description = ${this._mobileDescription_}`;
                          
            return mobDetails;              
      }
}

class basicPhone extends mobile{
    constructor(mobileId,mobileName,mobileDescription,mobileType){
        super(mobileId,mobileName,mobileDescription);
        this._mobileType_ = mobileType;
    }
    printMobiledetails(){
        let allDetails = super.printMobiledetails() + 
        "mobile type: "+ this._mobileType_;
        return allDetails;
    }
}

class smartPhone extends mobile{
    constructor(mobileId,mobileName,mobileDescription,mobileType){
        super(mobileId,mobileName,mobileDescription);
        this._mobileType_ = mobileType;
    }
    printAllmobile(){
        let allDetails = super.printMobiledetails() + 
        "mobile type: "+ this._mobileType_;
        return allDetails;
    }
}

var smartPhoneObj = new smartPhone("123","samsung","RAM5GB",
                                "Screentouch");
   console.log(smartPhoneObj.printMobiledetails());

var basicPhoneObj = new basicPhone("111","Apple","RAM10GB","keypad");
   console.log(basicPhoneObj.printMobiledetails());

   //CRUD operation
   let Allmobile=[];
    Allmobile.push(basicPhoneObj);
    Allmobile.push(smartPhoneObj);

    for(var mobil in Allmobile){
        console.log(Allmobile[mobil].printMobiledetails());
    }

    //delete
    console.log(typeof(Allmobile[0]._mobileId_));

    let mobileId= parseInt(prompt("enter mobile id"));
    for(let mobile in Allmobile){
        if(Allmobile[mobile]._mobileId_== mobileId){
            Allmobile.splice(mobile,1);
        }
    }
    for(let mobile in Allmobile){
        console.log(Allmobile[mobile].printMobiledetails());
    }