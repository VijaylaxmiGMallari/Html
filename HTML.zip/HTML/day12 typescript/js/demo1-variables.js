var eid = 101;
var ename = "Narend";
var salary = 25000.00;
var empstatus = true;
console.log("Employee Id is " + eid);
console.log("Employee Name is " + ename);
console.log("Employee Salary is " + salary);
if (empstatus)
    console.log("Employee is selected..");
else
    console.log("Employee is Rejected..");
