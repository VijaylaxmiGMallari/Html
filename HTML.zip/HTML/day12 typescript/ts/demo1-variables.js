//Base Type of Built - in Data Typrand custom types
//Dynamic type
var someType = 10;
//Class Name for number Type is Number
console.log("someType here: typeOf: " + typeof (someType));
someType = "Hello World";
//Class Name for string Typr is String
console.log("someType here: typeOf: " + typeof (someType));
//Class Name for Boolean type is boolean
someType = true;
console.log("someType here: typeOf: " + typeof (someType));
someType = null;
console.log("someType here: typeOf: " + typeof (someType));
someType = undefined;
console.log("someType here: typeOf: " + typeof (someType));
//Declaration Variables
//static type - once declared any variables with some type
//through  the scope, it cannot be any other type
var eid = 101;
var ename = "Narend";
var salary = 25000.00;
var empstatus = false;
//Displaying Variables
console.log("Employee Id is " + eid);
console.log("Employee Name is " + ename);
console.log("Employee Salary is " + salary);
if (empstatus)
    console.log("Employee is selected..");
else
    console.log("Employee is Rejected..");
