//Arrow operator with  parameter
var circle = function (r) { return 3.142 * r * r; };
//Arrow Operator without parameter
var areaOfCircle = function () { return console.log(circle(5)); };
areaOfCircle();
function calculateArea(a, b) {
    var area;
    if (b === undefined)
        area = 3.142 * a * a;
    else
        area = a * b;
    return area;
}
//Circle
console.log("Area of circle is" + calculateArea(10));
//Rectangle
console.log("Area of square is ", calculateArea(10, 20));
