//Arrow operator with  parameter
let circle = (r) => 3.142*r*r;

//Arrow Operator without parameter
let areaOfCircle = () =>console.log(circle(5));

areaOfCircle();


//Function Overloading

function calculateArea(radius: number): number;
function calculateArea(length: number, b?: number):number;

function calculateArea(a:number, b?:number):number{
    let area:number;
    if(b === undefined)
          area = 3.142*a*a;
          else
             area = a*b;

             return area;
}

//Circle
console.log("Area of circle is" +calculateArea(10));
//Rectangle
console.log("Area of square is " calculateArea(10,20));


//Anonymous function with parameters
var res = function(a:number,)


//The Function Constructor
var myfunction = new Function("a","b","return a*b");
var product = myfunction(4,3);
console.log(product);

//Parameter type Inference
// -> Based on initialied value, type will be decided is 
//known as Typr Interference
var showType = (x) =>{
    if(typeof x == "number"){
        console.log(x +"is numeric")
    }else if (typeof x =="string"){
        console.log(x +"is a string"){

        }
    }
}

showType(12)
showType("Hello");

//Rest Parameter - Variable length number of arguments
function addNumbers(...nums:number[]){
    var i;
    var sum:number = 0;

    for(i=0;i<nums.length;i++){
        sum = sum +nums[i];
    }
    //OR using For..in Loop
    //for(i in nums){
     //sum+=i;   
    //}

console.log("sum of the numbers",sum)
}
addNumbers(1, 2, 3)
addNumbers(10,10,10,10)