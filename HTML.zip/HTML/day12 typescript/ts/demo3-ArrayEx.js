var numbers = [10, 20, 30, 40, 50];
console.log("Display Numbers...!");
for (var n in numbers) {
    console.log(n);
}
