var numbers:number[] = [10,20,30,40,50];

console.log("Display Numbers...!");
for(let n in numbers){
    console.log(n);
}

//Declaration array  using Array() Constructor

var newNumbers = new Array(5);
console.log("Display New Numbers..!");
for(let i=0; i<newNumbers.length; i++){
    newNumbers[i] = numbers[i] + 10;
}
console.log(...newNumbers);

//Declaration array  using Array() Constructor
var newNumbers = new Array(5);
console.log("Display New Numbers..!");
for (var i = 0; i < newNumbers.length; i++) {
    newNumbers[i] = numbers[i] + 10;
}
console.log.apply(console, newNumbers);

//Array Constructor accepts comma separated values
var studentsList: string[] = 
            new Array("Anusha","Vijaylaxmi","Ramitha","Raksha")

    console.log(...studentsList);


//Array Destruction 
var arrObj: number[] = [10,10]
var[x,y] = arrObj
console.log(x)
console.log(y)

//shift() - Removes the first element from an array
 

//2nd array
var twoDArray: number[][] = [[1,2,3],[21,22,23]]
console.log(...twoDArray);