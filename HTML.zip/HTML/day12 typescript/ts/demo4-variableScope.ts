var global_Num:number = 100;

class VariableScope{
    //instance variable which requires object to access
    //life time of this variable depends o objects
    //it is bound to object
    instance_num:Number =10;

   //class variable or static variable which requires classname
   //life time of this variable is depend on class
   //it is bound to class
   static static_Num:number = 1000;

    //non static function
    //non static funcction can access non static members
    //non static members
    displayNum(local_Num: number = 5){
        console.log("global_Num : " +global_Num);
        console.log("instance_Num :" +this.instance_Num);
        console.log("local_Num :" +local_Num);
    }


    //static function
    //static function can access only static memberss
    //non static members are not allowed
    //But you can declare non static member inside static function
    static displayStaticNumber():void{
        console.log(VariableScope.static_Num);
        //console.log("instance_Num :" +this.instance_Num);
        //non static member declaratrion
        //let num:number = 20;
    }
}

var obj = new VariableScope();
console.log("/n/tglobal_Num: " +global_Num);

console.log("VariableScope.static_Num :" +VariableScope.static_Num);


//calling with default parameters
obj.displayNum();
//calling with parameter
obj.displayNum(20);