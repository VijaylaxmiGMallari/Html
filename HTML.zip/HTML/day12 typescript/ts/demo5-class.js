//Understanding Access specifiers
//[public , private, protected]
classMyClass;
{
    companyName: string = "IGATE";
}
var myClassObj = new myClassObj();
console.log("Instance of Keyword: " + (myClassObj instanceof MyClass));
//Accessing public member outside the class
console.log("Default Name: ", myClassObj.companyName);
//changing name
myClassObj.companyName = "capGemini";
//Accessing public members outside the class
console.log("After Name changfe: " + myClassObj.companyName);
//Using constructors to initialize class members
//Using Inheritence Between Classes
