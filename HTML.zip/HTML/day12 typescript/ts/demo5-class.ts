//Understanding Access specifiers
//[public , private, protected]
class MyClass{
    companyName: string= "IGATE";

}
var myClassObj = new MyClassObj();
console.log("Instance of Keyword: " +(myClassObj instanceof MyClass));

//Accessing public member outside the class
console.log("Default Name: "MyClassObj.companyName);

//changing name
myClassObj.companyName = "capGemini";
//Accessing public members outside the class
console.log("After Name changfe: " + myClassObj.companyName);





//Using constructors to initialize class members
class Product{
    //member variables
    firstNumber: number;
    secondNumber : number;

    constructor(firstNumber: number, secondNumber:number){
        this.firstNumber = firstNumber;
        this.secondNumber = secondNumber;
    }
    calculateProduct(): number{
        let result = this.firstNumber*this.secondNumber;
        return result;
    }
}// end of Product class

var myProduct1 = new Product(100,200);
console.log("\n\nProduct of 2 numbers" +myProduct1.calculateProduct());

var myProduct2 = new Product(100,200);
console.log("\n\nProduct of 2 numbers" +myProduct2.calculateProduct());

//Type of Inhritence
/* 
   1-Single Level - Only one parent class and child class
   2-Multi Level - child class can be derived from more than one 
   parent class.It is  supported directly in Typescript.
   We have to use interface for that
   */


//Using Inheritence Between Classes and Method Overridding

class Geometry{
    //Base Class Members
    protected side:number;
    protected base: number;
    protected height: number;

    //Base Class Function
    calculate(): void{}
}

class Square extends Geometry{
    static counter: number = 0;
      constructor(side: number){
          super();
          this.side = this.side;
          Square.counter++;
      }
      //overriding calculate() function of Geometry class
      calculate(): void{
          let area= this.side*this.side;
          console.log("Area of Square:" +area);
      }
      static getCount(): number{
          return Square.counter;
      }
}
let squareObj1 = new Square(5);
squareObj.calculate();

let squareObj2 = new Square(15);
squareObj.calculate();

let squareObj3 = new Square(25);
squareObj.calculate();
console.log("Square.counter");
