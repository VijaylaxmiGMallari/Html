interface IHDFCBank{
    hoursOfWork:number
}
interface ICitiBank {
    projectName:string
}
//java syntax of implementing interfaces
class Employee implements IHDFCBank, ICitiBank {
    name:string;
    salary:number;
    //overriding members of IHDFCBank and ICitiBank
    projectName:string;
    hoursOfWork:number;

    constructor(name:string,salary:number,projectName:string,
        hoursOfWork:number){
        this.name=name;
        this.salary=salary;
        this.projectName=projectName;
        this.hoursOfWork=hoursOfWork;

    }
    printDetails():string {
        let details=
            ` project name ${this.projectName}
            employee name ${this.name}
            working hours ${this.hoursOfWork}
            salary ${this.salary}
            `;
            return details;
    }

}// end of class

let empObj=new Employee("anu",25200,"insurance automation",100);
console.log(empObj.printDetails());

//Implement print


//Generic Function or FunctionTemplates in C++
function addition<T>(firstNumber:T,secondNumber:T): T {
    return(<any>firstNumber + <any> secondNumber);
}

console.log(addition(20,30));
console.log(addition(30.5,60.8896));
