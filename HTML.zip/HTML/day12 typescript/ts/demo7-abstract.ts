abstract class Person{
  abstract  show():void{

    }
}
class Customer extends Person{
    show():void{
        console.log("This is overridden method");
    }


    
}

//let personObj = new Person();
//Dynamic Polymorphism
let customerObj:Person = new Customer();
customerObj.show();