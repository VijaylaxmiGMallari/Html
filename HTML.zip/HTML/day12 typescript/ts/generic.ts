function addition<T>(firstNumber:T,secondNumber: T): T{
    return (<any> firstNumber+ <any> secondNumber);
}
console.log(addition(20,30));
console.log(addition(20.33333,30.63));
console.log(addition(90.33333,30.63));
console.log(addition("vijay","laxmi"));

//  generic class
class Calculator <T>
{
    add:(one:T,two:T)=> T;

}
var result=  new Calculator<number> ();
result.add=function(x,y) {return x+y;}
console.log(result.add(50,60));
//fn template
class Calculator <T>
{
    add(one:T, two:T)  {
    return <any> one + <any> two;

}

}
var obj1=new Calculator<number>();
console.log(obj1.add(10,20));

var obj2=new Calculator<string>();
console.log(obj2.add("100","20"));
