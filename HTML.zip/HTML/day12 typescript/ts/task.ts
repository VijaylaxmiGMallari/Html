interface openAccount{
    accountisOpened:string
}
interface closeAccount {
    accountisClosed:string
}

interface 
//java syntax of implementing interfaces
class Employee implements IHDFCBank, ICitiBank {
    name:string;
    salary:number;
    //overriding members of IHDFCBank and ICitiBank
    projectName:string;
    hoursOfWork:number;

    constructor(name:string,salary:number,projectName:string,
        hoursOfWork:number){
        this.name=name;
        this.salary=salary;
        this.projectName=projectName;
        this.hoursOfWork=hoursOfWork;

    }
    printDetails():string {
        let details=
            ` project name ${this.projectName}
            employee name ${this.name}
            working hours ${this.hoursOfWork}
            salary ${this.salary}
            `;
            return details;
    }

}// end of class

let empObj=new Employee("anu",25200,"insurance automation",100);
console.log(empObj.printDetails());

//Implement print