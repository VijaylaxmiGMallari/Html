//import * as shapes from "./shapes";
//let triangleObj = new shapes.Shapes.Triangle(); // shapes.Shapes?
//console.log(triangleObj.show());

//OR

import {Shapes} from "./shape";
let triangleObj = new Shapes.Triangle();
console.log(triangleObj.show());