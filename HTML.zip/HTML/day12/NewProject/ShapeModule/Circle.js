"use strict";
//import shape = require("./IShape");
//export class Circle implements shape.IShape{
//   
//}
exports.__esModule = true;
var Circle = /** @class */ (function () {
    function Circle() {
    }
    Circle.prototype.draw = function () {
        console.log("Circle is drawn (external module)");
    };
    return Circle;
}());
exports.Circle = Circle;
