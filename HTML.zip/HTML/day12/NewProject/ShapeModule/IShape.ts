export interface IShape{
    draw();

    //To calculate area of shapes
    area(base:number,height?: number):number;
}