//import shape = require("./IShape");
//export class Circle implements shape.IShape{
//   
//}

import {IShape} from "./IShape";

export class Triangle implements IShape {
    public draw(){
        console.log("Triangle is drawn (external module)");
    }

    public area(base:number,height:number):number{
        let areaOfTriangle = 0.5*base*height;
       return areaOfTriangle;
       }
}