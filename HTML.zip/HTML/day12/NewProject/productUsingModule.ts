//import {IProduct} from  "./productModule/Product";
//import {company} from " ./productModule/Product";

//OR

import{company,Product} from "./productModule/product";

//Declare Product
let prod: Product = {productId:1001, productName:"iPhone"}

let productArray:Product[] = 
        [{productId:1002, productName:"LG"},
         {productId:1003, productName:"CoolPad"},
         {productId:1004, productName:"Mi"}];

console.log(prod.productId + " " +prod.productName+ "\n");

for(let pro of productArray){
    console.log(pro.productId+ " "+pro.productName+ "\n");
}
   console.log(company);
   
    