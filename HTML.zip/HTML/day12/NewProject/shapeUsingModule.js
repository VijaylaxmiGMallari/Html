"use strict";
//draw allShapes(new triangle.Triangle());
exports.__esModule = true;
var Circle_1 = require("./ShapeModule/Circle");
var Triangle_1 = require("./ShapeModule/Triangle");
function drawAllShapes(shapeToDraw) {
    shapeToDraw.draw();
}
drawAllShapes(new Circle_1.Circle());
drawAllShapes(new Triangle_1.Triangle());
