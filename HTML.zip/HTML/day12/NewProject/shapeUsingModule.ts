//draw allShapes(new triangle.Triangle());

//OR

import {IShape} from "./ShapeModule/IShape";
import {Circle} from "./ShapeModule/Circle";
import {Triangle} from "./ShapeModule/Triangle";

function drawAllShapes(shapeToDraw:IShape){
    shapeToDraw.draw();
}

drawAllShapes(new Circle());

drawAllShapes(new Triangle());

