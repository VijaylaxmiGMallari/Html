//Union
//Two or more data types are combined using the pipe symbol(|)
//to denote a Union Type. In other words, a union type is written
//as a sequence of types seprated by vertical bars
//e.g
var val;
val = 25;
console.log("Numeric value of val is" + val);
val = "Hello World";
console.log("string value of val is" + val);
//Union Type and function parameters
function disp(name) {
    if (typeof name == "string") {
        console.log(name);
    }
    else {
        var i;
        for (i = 0; i < name.length; i++) {
            console.log(name[i]);
        }
    }
}
disp("Nihal");
console.log("Printing names array....");
disp(["Sandesh", "Jeevesh", "jatin", "Abhinav"]);
//Union Typr Array
var arrType;
var i;
arrType = [10, 20, 30, 40];
console.log("Numeric Array");
for (i = 0; i < arrType.length; i++) {
    console.log(arrType[i]);
}
arrType = ["Mumbai", "Pune", "Delhi"];
console.log("String Array");
for (i = 0; i < arrType.length; i++) {
    console.log(arrType[i]);
}
