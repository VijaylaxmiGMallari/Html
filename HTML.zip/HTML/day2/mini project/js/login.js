function login(frmLoginObj){
     if(frmLoginObj.checkValidity()){
         var username= frmLoginObj.txtUN.value;
         var password= frmLoginObj.txtPD.value;
        // alert(username);
        // alert(password);
         if(username == "Narend" && password=="123456")
         {
             alert('Login Successful..!');
             localStorage.setItem("username",username);
             //window.location="../pages/simpleInt.html";
             window.open("../pages/simpleInt.html");
             //alert(window.location);
         }
         else
          alert('Login Failed..!');
     }
}