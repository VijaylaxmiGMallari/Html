function usernameExist(){
    if(localStorage.getItem("username")== null){
        window.location = "../pages/login.html";
    } 
}
  function logout(){
      var result =confirm("DO you want to Logout?");
      if (result) {
        localStorage.removeItem("username");
        localStorage.clear();
      
if(localStorage.getItem("username")==null){
     window.location ="../pages/login.html";
}
} } 


function calculateSI(pa, noy,roi){
    if(pa.value ==""|| noy.value == ""
    || roi.value == ""){
        alert('Please fill all boxes..!');
        return;
    }
    var si= parseFloat(pa.value) *
              parseFloat(noy.value) *
                 parseFloat(roi.value)/100;
                document.getElementById("result")
                .innerHTML = "Simple Interest is"+ si;
}