/*showDate is Global variable and Date is built in 
class in javascript*/
var showDate = new Date();

/*This function will be invokedon[onload] event*/
function showDateTime(){
document.getElementById("showDate").innerHTML
    ="Today's Date and time is" + showDate;}