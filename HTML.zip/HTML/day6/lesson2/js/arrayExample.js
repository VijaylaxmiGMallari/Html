var listofBoys = ["Pawan","Kishore","Sagar"];
var listofGirls = 
                   new Array("Prathiba","Kavitha","Vijaya");
//Empty Declaration
//var numbers=[];
//var courses = new Array();

document.write("<h3>"+listofBoys+"</h3>");
document.write("<h3>"+listofGirls+"</h3>");

document.write("Display Boys using loops");
document.write("<h4>Boys Count: "+listofBoys.length+"</h4>");

for(var i=0; i<listofBoys.length;i++)
  document.write(listofBoys[i].bold()+"</br>");

  listofBoys.push("Mukund");
 document.write("<h3>Displaying Boys after adding Mukund</h3>" );
 document.write("<h3>" +listofBoys+ "<h3>");
document.write("<h4>Boys Count: " +listofBoys.length+ "</h4>");


  document.write("Display Girls using loops");
  document.write("<h4>Girls Count: "+listofGirls.length+"</h4>");

for(var i=0; i<listofGirls.length;i++)
  document.write(listofGirls[i].bold().italics()+"</br>");

  //Adding at the begining of the list
  listofGirls.unshift("Shreya");
  document.write("<h3>Displaying Girlss after adding Shreya</h3>" );
 document.write("<h3>" +listofGirls+ "<h3>");
document.write("<h4>Girls Count: " +listofGirls.length+ "</h4>");

//slice will return selected list of elements from
//an array without deleting it
//even you can add element in between or
//at specific location
listofGirls.splice(2,2,"Amiksha","Samiksha");
document.write("<h1>" +listofGirls+ "</h1>");

  document.write("<h3>Sort Girls in AscendingOrder</h3>")
  listofGirls.sort();
  for(var i=0; i<listofGirls.length;i++)
  document.write(listofGirls[i].bold()+"</br>");
  document.write(listofGirls[i].bold().italics()+"</br>");
  
  document.write("<h3>Sort Girls in DescendingOrder</h3>")
  listofGirls.reverse();
  for(var i=1; i<listofGirls.length;i++)
  document.write(listofGirls[i].bold()+"</br>");
  document.write(listofGirls[i].bold().italics()+"</br>");

