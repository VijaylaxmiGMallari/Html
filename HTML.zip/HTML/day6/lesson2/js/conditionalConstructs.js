function checkEvenOrOdd(num){
    var result;
    if(num.value ==0)
        result="0 is Neither Even Nor Odd..!";
    else if(num.value %2==0)
        result=num.value+ "is a Even Number";

        else 
        result=num.value+ "is a odd Number";

        alert(result);
}

function Number(a,b){
    var res;
    if(a.value>b.value)
    res="a is greater than b";
    else if(a.value<b.value)
    res="a is less than b";
    else
    res="both are equal";
    alert(res);
}

function Alphabets(a){
      var alphabet;
      alert("1");
      switch(a){
          case a:
          case e:
          case i:
          case o:
          case u:
          {
            alphabet=vowel;
          }
          break;
          case b:
          case c:
          case d:
          case f:
          case g:
          case h:
          case j:
          case k:
          case l:
         {
             alphabet=consonant;
         }

      break;

      }
}
alert("alphabet");