var anyType;

document.write("Type:" +typeof(anyType)+" " +"Value: "+anyType);

anyType="vijaya";
document.write("<br>Type:" +typeof(anyType)+" " +"Value: "+anyType);

anyType="10000";
document.write("<br>Type:" +typeof(anyType)+" " +"Value: "+anyType);

anyType="false";
document.write("<br>Type:" +typeof(anyType)+" " +"Value: "+anyType);

anyType="null";
document.write("<br>Type:" +typeof(anyType)+" " +"Value: "+anyType);
