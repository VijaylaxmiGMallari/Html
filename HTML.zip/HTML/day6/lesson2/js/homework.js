function aplhaBets(a){
    var alphabets
     switch(a){
        case a:
        case e:
        case i:
        case o:
        case u:
        {
            alphabets=vowel;
        }
        break;
        case b:
        case c:
        case d:
        {
            alphabets=consonant;
        }
     }
    alert("alphabets");
}