function findFactorial_ForLoop(num){
    if(num.value =="")
    alert("Plz Enter a Numberic value")
    else
    {
        var n= parseInt(num.value)
        var fact=1;
        for(var i=1; i<=n; i++)
           fact*=i;
           alert("Factorial of"+n+ "is" +fact);

    }
}


function findFactorial_WhileLoop(num){
    if(num.value=="" || isFinite(num.value))
    alert("Plz Enter a Numberic value")
    else
    {
        var n= parseInt(num.value)
        var fact=1;
        var i=1;
        while(i<=n) 
           fact*=i;
           i++;
           alert("Factorial of"+n+ "is" +fact);

    }
}
/*Function with variable number of Arguments */
function function_Arguments(seperator){
    var result;
    for(var i=1; i<arguments.length;i++)
         result+= arguments[i] + seperators;

         document.write("<h2>" +result+"</h2>");
}

function  addition(){
     var sum=0;
     for(var i=0; i<arguments.length;i++)
     sum+=parseInt(arguments[i]);
     return sum;
}

document.write
