function DisplayDays(month,Year){
    var days;
    switch(parseInt(month.value))
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
        {
            days=31;
        }
        break;
        case 4:
        case 6:
        case 9:
        case 11:
        {
            days=30;
        }
        break;
        case 2:
        {
            if(Year.value%4==0)
            {
                days=29;
            }
            else 
            {
                days=28;
            }

        }
        break;
        default:{
            day=-1;
        }
     }
     if(days==-1)
     alert("Invalid Month")
     else
     alert(month.value+"has"+days+"days");
}

function Number(a,b){
    var res;
  res=a.value>b.value ? +"is greater than":a.value<b.value ? b.value +"is greater": "both are equal";
   alert(res);
}