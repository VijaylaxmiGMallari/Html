function  calculateACircle(){
    calculate();
}
function calculate(){
    var radius = parseFloat(prompt("Enter radius:"));

    var area=Math.PI*radius*radius;

    alert("Area of the Circle is" +area);

    var result=confirm("Do you want to continue?");
    if (result==true)
    {
        calculate();
    }
}
//set Interval() and clear Interval
 var intervalObj;
 function setIntervalFunc(){
      intervalObj = setInterval(function(){
          alert("Hello World");

      },5000);   
 }

 function clearIntervalFunc(){
     clearInterval(intervalObj);
     alert('u have stopped');
 }

 //set TimeOut() and clear Timeout
 var TimeoutObj;
 function setTimeoutFunc(){
      alert('U have started Timeout');
      Timeoutobj = setTimeout(function(){
          alert("Hello World");

      },3000);   
 }

 function clearTimeoutFunc(){
     clearTimeout(TimeoutObj);
     alert('u have stopped timeout');
 }

 function display(){
     var message = this.id+" "+this.name+" "
     +this.design+" "+this.salary;
     alert(message);
 }
//creatingobject in javaScript without class
 var emp1 = new Object;
 emp1.id = 101;
 emp1.name = "Anand";
 emp1.design = "Developer";
 emp1.salary = 25000;
  //storing ref for one func in another func
 emp1.displayEmp =display;

 emp1.displayEmp();

 var emp2 = new Object;
 emp2.id = 102;
 emp2.name = "Amit";
 emp2.design = "Tester";
 emp2.salary = 22000;
 //storing ref for one func in another func
 emp2.displayEmp = display;
 emp2.displayEmp();
