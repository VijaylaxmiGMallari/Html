function setEmpDetails(eid,name,desig,salary){
    this.eid = eid;
    this.name = name;
    this.desig = desig;
    this.salary = salary;

    displayEmpDetails = function(deptName){
        var details = `Emp Id:${this.eid} \n
                       Emp Name : ${this.name}\n
                       Dept Name: ${deptName} \n
                       Designation:${this.desig} \n
                       Salary:${this.salary}`;

                    //    alert(details);

      var empObj= window.open("","Emp Details","width=400px; height=500px");
        var empDetails=
      ` <html>
               <head>
               <title></title>
           </head>
         <body>
                  <table>
                     <tr>
                        <th>Eid</th>
                        <td>${this.eid}</td>
                   </tr>
                  <tr>
                       <th>Name</th>
                   <td>${this.name}</td>
                    </tr>
                  <tr>
                       <th>Department</th>
                       <td>${this.deptName}</td>
                    </tr>
                     <tr>
                         <th>Designation</th>
                        <td>${this.desig}</td>
                   </tr>
                     <tr>
                         <th>Salary</th>
                        <td>${this.salary}</td>
                     </tr>
                </table>
             </body>
         </html>`;
        empObj.document.write(empDetails);
    }                     
}