db.createCollection("employees")

db.employees.find({})
//Insert Data In employees Collections
		db.employees.insert({_id:111,firstname:"Anita",lastname:"Gokhle"})		
		db.employees.insert({_id:333,firstname:"Raja",lastname:"Josji",age:30,salary:80000.0,isEmployee:true})
		db.employees.insert({_id:444,firstname:"Santosh",lastname:"Pakhale",age:10,salary:30000.0,isEmployee:false})
		db.employees.insert({_id:555,firstname:"Harishwar",lastname:"Mendre"})
		db.employees.insert({_id:222,firstname:"Vaishali",lastname:"Joshi",age:23,salary:22000.0,isEmployee:true})	
		
		db.employees.find({})
		
		db.employees.find({"firstname":"Anita"})
		
		
		//1)Fetch employees based on unique id value
		db.employees.find({ "_id" : ObjectId("5c8f83970dcd4f2314230bb3")})
		//2)show all employee details without firstname, lastname, address field
		db.employees.find({},{"firstname":0,"lastname":0,"address":0}).pretty()
		//3)Add array of employee objects
		db.employees.insert([{firstname:"vrushali",lastname:"Tambe",age:30,salary:12000.0,isEmployee:false},{firstname:"sameer",lastname:"kanase",age:24,salary:15000.0,isEmployee:true}])
		
		//4)Find all data with pretty function
		db.employees.find().pretty()
		//5)Remove all records
		
		db.employees.remove({})
		
	//step do to->	Add More Data As follows
		db.employees.insert([
    		{
		 firstname:"Tanmaya",
  		 lastname:"Acharaya",
  	 	 gender:"Male",
  		 age:50,
  		 salary:90000.0,
  		 address:
		 {
			street:"44,Whitefield",
			city:"Banglore",
			state:"KS"
		 },
		 contacts:["9878666666","030-34556"]
    		},
    		{
			 firstname:"shilpa",
  			 lastname:"bhosale",
  			 gender:"Male",
  	 		 age:60,
  	 		 salary:45000.0,
  	 		 address:
	 		 {
				street:"67,MGRoad",
				city:"Mumbai",
				state:"MS"
	 		 },
	 		contacts:["88888108810","020-787777"]
    		},
    		{
			 firstname:"Kadiresan",
  			 lastname:"K",
  	 		 gender:"Male",
  	 		 age:29,
  	 		 salary:80000.0,
  	 		 address:
			 {
				street:"Sipcot",
				city:"Chennai",
				state:"TS"
			 },
			 contacts:["7786666666","044-878888"]
   		 },
		{
			 firstname:"Rahul",
  			 lastname:"Kulkarni",
  	 		 gender:"Male",
  	 		 age:34,
  	 		 salary:32000.0,
  	 		 address:
			 {
				street:"Aundh",
				city:"Pune",
				state:"MS"
			 },
			 contacts:["9889788864","99-888679"]
   		 }
	])
	
	//6)Remove only first document found with firstname "Rahul"
		
		db.employees.remove({ "firstname":"Rahul"},1)
		
		//7)Find Documents with firstname Rahul
		
		db.employees.find({firstname:"Rahul"})
		
		//8)Find the documents for those whose age is greater than 40
		
		db.employees.find({age:{$gt:40}})
		//9)Find firstname lastname and age for those employee having 
		age greater than 50 with first 5 record
		
		db.employees.find({age:{$gt:50}},{firstname:1,lastname:1,age:1}).limit(5).pretty()