show dbs

use mydatademo
db.createCollection("student" )
show dbs
show collections
db.student.drop()

//insert values
db.student.insert({
    "studentno":4,
    "firstname":"rahima",
    "lastname":"pawair",
    "age":31
})

//


db.student.find({})



//to insert many records inta an array
db.student.insertMany([
     {"studentno":2, "firstname":"rahim","lastname":"pawar","age":32},
     {"studentno":3, "firstname":"mahim","lastname":"powar","age":30},
     {"studentno":4, "firstname":"rahima","lastname":"pawair","age":31},
    
])

//find one only one record
db.student.findOne({})

//find the record where student id is 2
db.student.find({"studentno":2})

db.student.find({"firstname":"mahim"})

//db.student.find({"_id" : ObjectId("5c8f6d1a0dcd4f2314230b8a"),})

db.student.find({},{"firstname":1,"_id":0})

db.student.find({},{"age":1,"_id":0})

//projection criteria with conditions
db.student.find({})

db.student.find({"age":{$gt:30}})

db.student.find({"age":{$lt:32}})

db.student.find({"age":{$ne:30}})

db.student.find({"age":{$gte:31}})

//remove all the documents
db.student.remove({})


//remove only a record  with id
db.student.remove({"studentno":1})

db.student.insert({
    "studentno":1,
    "firstname":"rashmi",
    "lastname":"pawaskar",
    "age":33
})



