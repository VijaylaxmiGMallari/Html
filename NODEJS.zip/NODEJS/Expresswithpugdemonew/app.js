const express=require('express');
const path=require('path');
//initialize the app project
const app=express();

//load the view engilne
app.set('views',path.join(__dirname,"views"));
app.set("view engine","pug");

//defimig the routes
app.get('/',function(req,res){
    let emp=[
        {
            empId:1001,
            empName:'Sagar',
            empDep:'IT',
            empSalary:10000

        },
        {
            empId:1002,
            empName:'viju',
            empDep:'IT',
            empSalary:1000

        }
    ];
    res.render('index',{
        title:'this is my  title for index page',
        empData:emp
    });
});

app.get('/home',function(req,res){
    res.render('home',{
        mydata:'this is my data for home'
    });
});


app.listen(7654,function(){
    console.log('server is started on port 5000');
});