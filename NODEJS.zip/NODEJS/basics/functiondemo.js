function helloword(name){
    console.log("Welcome to" +name);
}

//callthe hello world function
helloword('Hello World');