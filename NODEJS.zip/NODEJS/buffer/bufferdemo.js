var b=Buffer.alloc(10);
var noOfBytesWritten=b.write("This is my sample buffer");
console.log("Bytes written:" + noOfBytesWritten);
console.log(b.toString());