setTimeout(function(str1,str2){
    console.log(str1 +" "+str2);

},5000,"Hello.","How are you?");