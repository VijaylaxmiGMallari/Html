var mod1obj=require('./mode1.js');




//  console.log(mod1obj.getData());
//  console.log(mod1obj.getLogin());

 mod1obj.getData();
 mod1obj.getLogin();