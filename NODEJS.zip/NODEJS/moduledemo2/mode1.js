var hello={
    getData:function(){
        console.log("In get data");

    },
    getLogin:function(){
        console.log("In get login");

    }
}
module.exports=hello;