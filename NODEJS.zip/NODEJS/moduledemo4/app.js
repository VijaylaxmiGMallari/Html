var data=require('./lib/mod.js');

data.emp();
data.pro();