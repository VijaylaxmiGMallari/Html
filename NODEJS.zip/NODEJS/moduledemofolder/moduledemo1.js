var mod1obj=require('./lib/mod1');
var mod2obj=require('./lib/mod2');

//calling files data using oject
console.log(mod1obj);
console.log(mod1obj.id);

console.log(mod1obj.doget());
console.log(mod2obj.id);