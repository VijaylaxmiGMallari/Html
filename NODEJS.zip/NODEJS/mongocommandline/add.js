let 
user1= 

{

"username":"Sachin","password":"Sachin",

"email":"Sachin@gmail.com",

"carts":[

{"id":1,"name":"IPhone","cost":98989,"quantity":2},

{"id":2,"name":"EarPhone","cost":9898,"quantity":2}

],

"orders":[

{"orderid":1000,"orderdate":"19-08-2018",

status:"delivered"},

{"orderid":1001,"orderdate":"29-08-2018",

"status":"pending"}

],

"orderItem":[

{"orderItemId":10001,"name":"IPhone",

cost:98989,"quantity":2,"orderid":1000},

{"orderItemId":10002,"name":"EarPhone",

cost:9898,"quantity":2,"orderid":1000},


{"orderItemId":10003,"name":"Chair",

cost:1000,"quantity":1,"orderid":1001},

{"orderItemId":10004,"name":"Table",

cost:2000,"quantity":1,"orderid":1001}


]

}