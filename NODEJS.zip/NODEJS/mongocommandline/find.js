var mongodb=require('mongodb');

var MongoClient=mongodb.MongoClient;
var url='mongodb://localhost/user1';
MongoClient.connect(url,function(err,client){
if(err){
    console.log(err);
}else{
    console.log('Connection establish....',url);
    var db=client.db('user1');
    var collection=db.collection('users');

    collection.find({
        $and:[{"username":"Sachin"},{"password":"Sachin"}]
    }).toArray(function(err,res){
if(err){
    console.log(err);
}else{
    console.log(res);
}
    });

}
});