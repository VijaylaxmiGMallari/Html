const express=require('express');
 const app=express();
//route methods
app.get('/',function(req,res){
    res.send('This is root path');
});

app.get('/home',function(req,res){
    res.send('Home Page');
});
//We will start the server
app.listen(1000,function(){
    console.log('server is running on port 1000');
})





