const 
http =require('http');

const 
server =http.createServer((req,res)=>{

if(req.url ==='/')

{

res.write('Hello wolrd');

res.end();

}
if(req.url ==='/hi')

{

res.write('Hello Annu');

res.end();

}

if(req.url==='/api/courses'){




res.write(JSON.stringify([1,2,3]));

res.end();

}});

server.listen(9900);

console.log('listening on port 3000...');