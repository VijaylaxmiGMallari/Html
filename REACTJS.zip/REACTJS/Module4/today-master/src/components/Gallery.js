import React, { Component } from 'react'

export class Gallery extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}

export default Gallery
