import React, { Component } from 'react'
import {connect} from 'react-redux'
import {incrementCounter,decrementCounter} from '../actions/counteractions'
export class Counter extends Component {
   
  render() {
    const{count,incrementCounter,decrementCounter}=this.props;
    return (
      <div>
          <button onClick={()=>decrementCounter()}>-</button>
          <span>{count}</span>
          <button onClick={()=>incrementCounter()}>+</button>
        
      </div>
    )
  }

  
}

const mapStatetoProps=(state)=>({
    count:state
})
const mapDispatchToProps=(dispatch)=>({
    decrementCounter:()=>dispatch(decrementCounter()),
    incrementCounter:()=>dispatch(incrementCounter()),
})

export  default connect(mapStatetoProps,mapDispatchToProps)(Counter);

